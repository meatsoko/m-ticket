import { useState } from 'react'
import { TODAY_BOOKINGS, PENDING_REQUESTS, PAST_UNPAID, VENUE } from '../data'
import { StatusPill, PayPill } from '../components/Pill'
import type { Booking } from '../types'

const SOURCE_ICON: Record<string, string> = { walkin: '🚶', phone: '📞', whatsapp: '💬', app: '📱' }

function StatCard({ label, value, sub, valueColor }: { label: string; value: string; sub?: string; valueColor?: string }) {
  return (
    <div style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 14, padding: '14px 14px 12px' }}>
      <div style={{ fontSize: 12, color: 'var(--color-muted)', fontWeight: 500, marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 24, fontWeight: 700, color: valueColor || 'var(--color-text)', lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: 'var(--color-muted)', marginTop: 4 }}>{sub}</div>}
    </div>
  )
}

export default function TodayScreen({ onNewBooking, onBookingTap }: { onNewBooking: () => void; onBookingTap: (b: Booking) => void }) {
  const [dismissed, setDismissed] = useState<string[]>([])
  const visibleRequests = PENDING_REQUESTS.filter(r => !dismissed.includes(r.id))

  const upNext = TODAY_BOOKINGS.filter(b => b.status === 'confirmed' || b.status === 'pending').slice(0, 6)
  const confirmed = TODAY_BOOKINGS.filter(b => b.status === 'confirmed')

  return (
    <div>
      {/* Header */}
      <div style={{ background: 'var(--color-primary)', padding: '52px 20px 20px' }}>
        <div className="flex items-center justify-between mb-1">
          <div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', fontWeight: 500, marginBottom: 2 }}>Tue 22 Sep 2026</div>
            <div className="flex items-center gap-2">
              <span style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>{VENUE.name}</span>
              <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', background: 'rgba(255,255,255,0.15)', padding: '2px 8px', borderRadius: 20 }}>▾</span>
            </div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 1 }}>{VENUE.area}</div>
          </div>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--color-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 15, color: 'var(--color-primary-dark)', flexShrink: 0 }}>AO</div>
        </div>
      </div>

      <div style={{ padding: '16px 16px 0' }}>
        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
          <StatCard label="Bookings today" value={`${confirmed.length}`} sub={`of ${TODAY_BOOKINGS.length} total`} />
          <StatCard label="Occupancy" value="72%" sub="21 of 29 hours" />
          <StatCard label="Collected" value="KES 31,000" sub="today" valueColor="var(--color-primary)" />
          <StatCard label="Unpaid" value="KES 7,500" sub="3 bookings" valueColor="var(--color-noshow)" />
        </div>

        {/* Needs attention */}
        {(visibleRequests.length > 0 || PAST_UNPAID.length > 0) && (
          <section style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--color-text)', marginBottom: 10 }}>Needs attention</div>

            {visibleRequests.map(r => (
              <div key={r.id} style={{ background: 'var(--color-pending-bg)', border: '1px solid #fde68a', borderRadius: 12, padding: '12px 14px', marginBottom: 8 }}>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div style={{ flex: 1 }}>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--color-text)' }}>{r.customer}</span>
                      <span style={{ fontSize: 12, color: 'var(--color-muted)' }}>{SOURCE_ICON[r.source]} via app</span>
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--color-muted)', marginTop: 2 }}>{r.pitch} · {r.time} · KES {r.amount.toLocaleString()}</div>
                  </div>
                  <StatusPill status="pending" />
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setDismissed(d => [...d, r.id])}
                    style={{ flex: 1, padding: '9px', borderRadius: 8, border: 'none', background: 'var(--color-primary)', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
                    Accept
                  </button>
                  <button onClick={() => setDismissed(d => [...d, r.id])}
                    style={{ flex: 1, padding: '9px', borderRadius: 8, border: '1px solid var(--color-border)', background: 'var(--color-surface)', color: 'var(--color-noshow)', fontSize: 14, fontWeight: 500, cursor: 'pointer' }}>
                    Reject
                  </button>
                </div>
              </div>
            ))}

            {PAST_UNPAID.map(b => (
              <button key={b.id} onClick={() => onBookingTap(b)} className="w-full text-left"
                style={{ width: '100%', background: 'var(--color-noshow-bg)', border: '1px solid #fca5a5', borderRadius: 12, padding: '12px 14px', marginBottom: 8, cursor: 'pointer', display: 'block' }}>
                <div className="flex items-center justify-between">
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--color-text)' }}>{b.customer}</div>
                    <div style={{ fontSize: 13, color: 'var(--color-muted)' }}>{b.pitch} · {b.time} · KES {b.amount.toLocaleString()} unpaid</div>
                  </div>
                  <PayPill status="unpaid" />
                </div>
              </button>
            ))}
          </section>
        )}

        {/* Up next */}
        <section style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--color-text)', marginBottom: 10 }}>Up next</div>
          <div style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 14, overflow: 'hidden' }}>
            {upNext.map((b, i) => (
              <button key={b.id} onClick={() => onBookingTap(b)}
                style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', borderBottom: i < upNext.length - 1 ? '1px solid var(--color-border)' : 'none', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                {/* Time */}
                <div style={{ width: 56, flexShrink: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--color-primary)' }}>{b.time.split('–')[0]}</div>
                  <div style={{ fontSize: 11, color: 'var(--color-muted)' }}>{b.pitch.replace('Pitch ', 'P')}</div>
                </div>
                {/* Customer */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--color-text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.customer}</div>
                  <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>{b.duration} · {SOURCE_ICON[b.source]}</div>
                </div>
                {/* Badges */}
                <div className="flex gap-1 flex-shrink-0">
                  <StatusPill status={b.status} />
                  <PayPill status={b.payment} />
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
