import { useState } from 'react'

const CUSTOMERS = [
  { name: 'Brian Otieno', phone: '+254 712 345 678', visits: 24, lastVisit: 'Mon 21 Sep', unpaid: 0, noShows: 0 },
  { name: 'Faith Wanjiru', phone: '+254 723 456 789', visits: 18, lastVisit: 'Tue 22 Sep', unpaid: 2500, noShows: 1 },
  { name: 'Kevin Mwangi', phone: '+254 734 567 890', visits: 31, lastVisit: 'Tue 22 Sep', unpaid: 1750, noShows: 0 },
  { name: 'Team Umoja FC', phone: '+254 745 678 901', visits: 9, lastVisit: 'Tue 22 Sep', unpaid: 6000, noShows: 0 },
  { name: 'Aisha Hassan', phone: '+254 756 789 012', visits: 5, lastVisit: 'Sun 20 Sep', unpaid: 0, noShows: 2 },
  { name: 'Dennis Kamau', phone: '+254 767 890 123', visits: 12, lastVisit: 'Sat 19 Sep', unpaid: 0, noShows: 0 },
  { name: 'Sandra Njeri', phone: '+254 778 901 234', visits: 7, lastVisit: 'Fri 18 Sep', unpaid: 0, noShows: 1 },
  { name: 'Moses Ochieng', phone: '+254 789 012 345', visits: 42, lastVisit: 'Tue 22 Sep', unpaid: 0, noShows: 0 },
  { name: 'Lydia Chebet', phone: '+254 700 123 456', visits: 15, lastVisit: 'Tue 22 Sep', unpaid: 2500, noShows: 0 },
]

export default function CustomersScreen() {
  const [query, setQuery] = useState('')
  const filtered = CUSTOMERS.filter(c =>
    c.name.toLowerCase().includes(query.toLowerCase()) ||
    c.phone.includes(query)
  )

  return (
    <div>
      <div style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)', padding: '52px 16px 12px' }}>
        <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--color-text)', marginBottom: 12 }}>Customers</div>
        <div style={{ position: 'relative' }}>
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder="Search name or phone…"
            style={{ width: '100%', padding: '10px 14px 10px 38px', borderRadius: 10, border: '1px solid var(--color-border)', background: 'var(--color-bg)', fontSize: 15, color: 'var(--color-text)', outline: 'none' }} />
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 16 }}>🔍</span>
        </div>
      </div>

      <div style={{ padding: '0 16px 16px' }}>
        {filtered.map((c, i) => (
          <div key={c.name} style={{ background: 'var(--color-surface)', borderRadius: i === 0 ? '0 0 12px 12px' : 12, border: '1px solid var(--color-border)', borderTop: i === 0 ? 'none' : '1px solid var(--color-border)', padding: '14px', marginBottom: 8, cursor: 'pointer' }}>
            <div className="flex items-start justify-between gap-2">
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="flex items-center gap-2">
                  <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--color-text)' }}>{c.name}</span>
                  {c.noShows >= 2 && <span style={{ fontSize: 11, background: 'var(--color-noshow-bg)', color: 'var(--color-noshow)', padding: '1px 6px', borderRadius: 10, fontWeight: 500 }}>⚠ {c.noShows} no-shows</span>}
                </div>
                <div style={{ fontSize: 13, color: 'var(--color-muted)', marginTop: 2 }}>{c.phone}</div>
              </div>
              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: c.unpaid > 0 ? 'var(--color-noshow)' : 'var(--color-muted)' }}>
                  {c.unpaid > 0 ? `KES ${c.unpaid.toLocaleString()} unpaid` : ''}
                </div>
              </div>
            </div>
            <div className="flex gap-4 mt-2">
              <span style={{ fontSize: 12, color: 'var(--color-muted)' }}>{c.visits} visits</span>
              <span style={{ fontSize: 12, color: 'var(--color-muted)' }}>Last: {c.lastVisit}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
