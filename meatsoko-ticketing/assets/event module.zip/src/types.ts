export type BookingStatus = 'confirmed' | 'pending' | 'completed' | 'noshow' | 'cancelled'
export type PaymentStatus = 'unpaid' | 'partpaid' | 'paid' | 'waived'
export type BookingSource = 'walkin' | 'phone' | 'whatsapp' | 'app'

export interface Booking {
  id: string
  ref: string
  customer: string
  phone: string
  pitch: string
  pitchType: string
  date: string
  time: string
  duration: string
  status: BookingStatus
  payment: PaymentStatus
  amount: number
  paid: number
  source: BookingSource
  notes?: string
}
