import { useState } from 'react'

export default function ProfileScreen() {
  const [smsReminders, setSmsReminders] = useState(true)
  const [bookingUpdates, setBookingUpdates] = useState(true)
  const [promos, setPromos] = useState(false)

  return (
    <div>
      <div style={{ background: 'var(--color-primary)', padding: '52px 16px 28px', textAlign: 'center' }}>
        <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'var(--color-accent)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 700, color: 'var(--color-primary-dark)', marginBottom: 10 }}>
          BO
        </div>
        <div style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>Brian Otieno</div>
        <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.75)', marginTop: 2 }}>+254 712 345 678</div>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 24, marginTop: 16 }}>
          {[['24', 'Bookings'], ['0', 'Unpaid'], ['0', 'No-shows']].map(([val, label]) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>{val}</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px' }}>
        {/* Account details */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--color-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Account</div>
          <div style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 14, overflow: 'hidden' }}>
            {[
              { label: 'Full name', value: 'Brian Otieno' },
              { label: 'Phone number', value: '+254 712 345 678' },
            ].map((item, i) => (
              <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 16px', borderBottom: i === 0 ? '1px solid var(--color-border)' : 'none' }}>
                <span style={{ fontSize: 15, color: 'var(--color-text)' }}>{item.label}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 15, color: 'var(--color-muted)' }}>{item.value}</span>
                  <span style={{ color: 'var(--color-muted-light)', fontSize: 18 }}>›</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Notifications */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--color-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Notifications</div>
          <div style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 14, overflow: 'hidden' }}>
            {[
              { label: 'SMS reminders', sub: '2 hours before your booking', val: smsReminders, set: setSmsReminders },
              { label: 'Booking updates', sub: 'Confirmations and changes', val: bookingUpdates, set: setBookingUpdates },
              { label: 'Promotions', sub: 'Deals from venues', val: promos, set: setPromos },
            ].map((item, i) => (
              <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderBottom: i < 2 ? '1px solid var(--color-border)' : 'none' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--color-text)' }}>{item.label}</div>
                  <div style={{ fontSize: 13, color: 'var(--color-muted)' }}>{item.sub}</div>
                </div>
                <button onClick={() => item.set(!item.val)}
                  style={{ width: 44, height: 26, borderRadius: 13, background: item.val ? 'var(--color-primary)' : 'var(--color-border)', border: 'none', cursor: 'pointer', position: 'relative', transition: 'background 0.2s', flexShrink: 0 }}>
                  <div style={{ width: 22, height: 22, borderRadius: '50%', background: '#fff', position: 'absolute', top: 2, left: item.val ? 20 : 2, transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Favourites */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--color-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Favourites</div>
          <div style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 14 }}>
            <button style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left' }}>
              <span style={{ fontSize: 20 }}>❤️</span>
              <span style={{ fontSize: 15, color: 'var(--color-text)' }}>Greenfield Arena</span>
              <span style={{ marginLeft: 'auto', color: 'var(--color-muted-light)', fontSize: 18 }}>›</span>
            </button>
          </div>
        </div>

        {/* Sign out */}
        <button style={{ width: '100%', padding: '14px', borderRadius: 14, border: '1px solid var(--color-border)', background: 'transparent', color: 'var(--color-noshow)', fontSize: 15, fontWeight: 500, cursor: 'pointer' }}>
          Sign out
        </button>
      </div>
    </div>
  )
}
