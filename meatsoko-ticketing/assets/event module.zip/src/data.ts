import type { Booking } from './types'

export const VENUE = {
  name: 'Greenfield Arena',
  area: 'Kilimani, Nairobi',
  pitches: [
    { id: 'A', name: 'Pitch A', type: '5-a-side', priceOffPeak: 2500, pricePeak: 3500 },
    { id: 'B', name: 'Pitch B', type: '7-a-side', priceOffPeak: 2500, pricePeak: 3500 },
    { id: 'C', name: 'Pitch C', type: '11-a-side', priceOffPeak: 3000, pricePeak: 4500 },
  ]
}

export const TODAY_BOOKINGS: Booking[] = [
  { id: '1', ref: 'TRF-4K7Q', customer: 'Brian Otieno', phone: '+254 712 345 678', pitch: 'Pitch A', pitchType: '5-a-side', date: 'Tue 22 Sep', time: '08:00–09:00', duration: '1h', status: 'confirmed', payment: 'paid', amount: 2500, paid: 2500, source: 'phone' },
  { id: '2', ref: 'TRF-9M2X', customer: 'Faith Wanjiru', phone: '+254 723 456 789', pitch: 'Pitch B', pitchType: '7-a-side', date: 'Tue 22 Sep', time: '10:00–11:00', duration: '1h', status: 'confirmed', payment: 'unpaid', amount: 2500, paid: 0, source: 'whatsapp' },
  { id: '3', ref: 'TRF-2R5T', customer: 'Kevin Mwangi', phone: '+254 734 567 890', pitch: 'Pitch A', pitchType: '5-a-side', date: 'Tue 22 Sep', time: '12:00–13:30', duration: '1.5h', status: 'confirmed', payment: 'partpaid', amount: 3750, paid: 2000, source: 'app' },
  { id: '4', ref: 'TRF-8W1P', customer: 'Team Umoja FC', phone: '+254 745 678 901', pitch: 'Pitch C', pitchType: '11-a-side', date: 'Tue 22 Sep', time: '14:00–16:00', duration: '2h', status: 'confirmed', payment: 'unpaid', amount: 6000, paid: 0, source: 'phone' },
  { id: '5', ref: 'TRF-5L3N', customer: 'Aisha Hassan', phone: '+254 756 789 012', pitch: 'Pitch B', pitchType: '7-a-side', date: 'Tue 22 Sep', time: '17:00–18:00', duration: '1h', status: 'confirmed', payment: 'unpaid', amount: 3500, paid: 0, source: 'walkin' },
  { id: '6', ref: 'TRF-7G6J', customer: 'Dennis Kamau', phone: '+254 767 890 123', pitch: 'Pitch A', pitchType: '5-a-side', date: 'Tue 22 Sep', time: '18:00–19:00', duration: '1h', status: 'pending', payment: 'unpaid', amount: 3500, paid: 0, source: 'app' },
  { id: '7', ref: 'TRF-3F9H', customer: 'Sandra Njeri', phone: '+254 778 901 234', pitch: 'Pitch C', pitchType: '11-a-side', date: 'Tue 22 Sep', time: '19:00–21:00', duration: '2h', status: 'pending', payment: 'unpaid', amount: 9000, paid: 0, source: 'app' },
  { id: '8', ref: 'TRF-6D4K', customer: 'Moses Ochieng', phone: '+254 789 012 345', pitch: 'Pitch B', pitchType: '7-a-side', date: 'Tue 22 Sep', time: '06:00–07:00', duration: '1h', status: 'completed', payment: 'paid', amount: 2500, paid: 2500, source: 'walkin' },
  { id: '9', ref: 'TRF-1B8C', customer: 'Lydia Chebet', phone: '+254 700 123 456', pitch: 'Pitch A', pitchType: '5-a-side', date: 'Tue 22 Sep', time: '07:00–08:00', duration: '1h', status: 'completed', payment: 'unpaid', amount: 2500, paid: 0, source: 'phone', notes: 'Regular customer, comes every Tuesday' },
]

export const PENDING_REQUESTS = TODAY_BOOKINGS.filter(b => b.status === 'pending')
export const PAST_UNPAID = TODAY_BOOKINGS.filter(b => b.status === 'completed' && b.payment === 'unpaid')
