import { useMemo, useState } from 'react'

type EventItem = {
  title: string
  date: string
  location: string
  price: string
  category: string
  image: string
  tone: string
}

const photos = {
  hero: 'https://images.unsplash.com/photo-1563132337-f159f484226c?auto=format&fit=crop&w=1200&q=90',
  crowd: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=900&q=85',
  stage: 'https://images.unsplash.com/photo-1528720335838-3f602fea2f0a?auto=format&fit=crop&w=900&q=85',
  party: 'https://images.unsplash.com/photo-1545128485-c400e7702796?auto=format&fit=crop&w=900&q=85',
  performer: 'https://images.unsplash.com/photo-1561409695-ce8315e7b9a6?auto=format&fit=crop&w=900&q=85',
  lights: 'https://images.unsplash.com/photo-1506157999258-a35364384ce9?auto=format&fit=crop&w=900&q=85',
  festival: 'https://images.unsplash.com/photo-1576328077645-2dd68934d2b7?auto=format&fit=crop&w=900&q=85',
  portrait: 'https://images.unsplash.com/photo-1707914882466-c7cd41d60f10?auto=format&fit=crop&w=900&q=85',
  fashion: 'https://images.unsplash.com/photo-1508174492734-7cce2629cadc?auto=format&fit=crop&w=900&q=85',
}

const categories = ['All events', 'Festivals', 'Business', 'Food & Drink', 'Fun Things', 'Gigs', 'Club Nights', 'Music', 'Comedy']

const events: EventItem[] = [
  { title: 'Afterdark: The Rooftop Sessions', date: 'FRI, 24 OCT · 9:00 PM', location: 'Canvas Yard, Bristol', price: 'From £12.00', category: 'Club Nights', image: photos.crowd, tone: '#ff2d3f' },
  { title: 'Pulse / Live at The Exchange', date: 'SAT, 25 OCT · 7:30 PM', location: 'The Exchange, Bristol', price: 'From £18.50', category: 'Gigs', image: photos.stage, tone: '#a940ff' },
  { title: 'No Signal: Warehouse Edition', date: 'SAT, 01 NOV · 10:00 PM', location: 'Motion, Bristol', price: 'From £16.00', category: 'Music', image: photos.performer, tone: '#ff603d' },
  { title: 'Sundown Social', date: 'SUN, 02 NOV · 4:00 PM', location: 'Thekla, Bristol', price: 'From £8.00', category: 'Food & Drink', image: photos.party, tone: '#f5bd36' },
  { title: 'Neon Frequency', date: 'FRI, 07 NOV · 8:00 PM', location: 'Marble Factory, Bristol', price: 'From £14.50', category: 'Festivals', image: photos.lights, tone: '#23a8ff' },
  { title: 'Lost in Stereo', date: 'SAT, 08 NOV · 9:30 PM', location: 'Lakota Gardens, Bristol', price: 'From £11.00', category: 'Club Nights', image: photos.festival, tone: '#ff2c9c' },
  { title: 'Culture Club: New Voices', date: 'THU, 13 NOV · 7:00 PM', location: 'Strange Brew, Bristol', price: 'From £9.50', category: 'Comedy', image: photos.fashion, tone: '#9de13c' },
  { title: 'Midnight Assembly', date: 'FRI, 14 NOV · 10:00 PM', location: 'Document, Bristol', price: 'From £15.00', category: 'Business', image: photos.portrait, tone: '#ff763b' },
]

function Button({ children, className = '', onClick, type = 'button', ariaLabel }: {
  children: React.ReactNode
  className?: string
  onClick?: () => void
  type?: 'button' | 'submit'
  ariaLabel?: string
}) {
  return <button type={type} className={className} onClick={onClick} aria-label={ariaLabel}>{children}</button>
}

function TextInput({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <label className="search">
      <SearchIcon />
      <input value={value} onChange={(event) => onChange(event.target.value)} placeholder="Search for events" aria-label="Search for events" />
    </label>
  )
}

function Brand() {
  return <div className="brand" aria-label="Bloco">BL<span>O</span>CO</div>
}

function SearchIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6" /><path d="m16 16 4 4" /></svg>
}

function ArrowIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
}

function CloseIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 5 14 14M19 5 5 19" /></svg>
}

function EventCard({ event, onOpen }: { event: EventItem; onOpen: () => void }) {
  return (
    <Button className="event-card" onClick={onOpen} ariaLabel={`View ${event.title}`}>
      <div className="event-image" style={{ '--tone': event.tone } as React.CSSProperties}>
        <img src={event.image} alt="" />
        <div className="event-tag">{event.category}</div>
        <div className="event-arrow"><ArrowIcon /></div>
      </div>
      <div className="event-copy">
        <div className="event-date">{event.date}</div>
        <div className="event-title">{event.title}</div>
        <div className="event-location">{event.location}</div>
        <div className="event-price">{event.price}</div>
      </div>
    </Button>
  )
}

export default function App() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All events')
  const [selected, setSelected] = useState<EventItem | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase()
    return events.filter((event) =>
      (category === 'All events' || event.category === category) &&
      (!term || `${event.title} ${event.location} ${event.category}`.toLowerCase().includes(term))
    )
  }, [category, query])

  const scrollToEvents = () => document.querySelector('#events')?.scrollIntoView({ behavior: 'smooth' })

  return (
    <main>
      <div className="noise" />
      <header>
        <TextInput value={query} onChange={setQuery} />
        <Brand />
        <nav className={menuOpen ? 'open' : ''}>
          <Button className="nav-link" onClick={scrollToEvents}>All events</Button>
          <Button className="nav-link" onClick={() => document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' })}>About us</Button>
          <Button className="sign-up">Sign up</Button>
          <Button className="sign-in">Sign in</Button>
        </nav>
        <Button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} ariaLabel="Toggle menu">
          <span /><span />
        </Button>
      </header>

      <section className="hero">
        <div className="hero-rings" />
        <div className="hero-orb">
          <div className="hero-flare" />
          <img src={photos.hero} alt="Woman in an orange suit posing confidently" />
        </div>
        <div className="hero-copy">
          <div className="eyebrow">BRISTOL / EST. 2025</div>
          <div className="display hero-title" role="heading" aria-level={1}>THE<br />CULTURE<br />ENGINE</div>
          <p>Built to power the pulse of modern culture.</p>
          <Button className="primary-button" onClick={scrollToEvents}>Explore events <ArrowIcon /></Button>
        </div>
        <div className="scroll-note">SCROLL TO DISCOVER <span /></div>
      </section>

      <section className="category-rail" aria-label="Event categories">
        <div className="category-track">
          {[...categories, ...categories].map((item, index) => (
            <Button key={`${item}-${index}`} className={`category-pill ${category === item ? 'active' : ''}`} onClick={() => { setCategory(item); scrollToEvents() }}>
              <span className="category-dot" />
              {item}
            </Button>
          ))}
        </div>
      </section>

      <section className="events-section" id="events">
        <div className="section-heading">
          <div>
            <div className="kicker">WHAT’S HAPPENING</div>
            <div className="display section-title" role="heading" aria-level={2}>{category === 'All events' ? 'POPULAR NOW' : category.toUpperCase()}</div>
          </div>
          <div className="result-count">{filtered.length.toString().padStart(2, '0')} EVENTS</div>
        </div>
        {filtered.length ? (
          <div className="events-grid">{filtered.map((event) => <EventCard key={event.title} event={event} onOpen={() => setSelected(event)} />)}</div>
        ) : (
          <div className="empty-state">
            <div className="display">NO SIGNAL</div>
            <p>Try another search or clear your filters.</p>
            <Button className="primary-button" onClick={() => { setQuery(''); setCategory('All events') }}>Reset search</Button>
          </div>
        )}
      </section>

      <section className="feature">
        <div className="feature-image"><img src={photos.festival} alt="Performer singing to an energetic crowd" /></div>
        <div className="feature-copy">
          <div className="kicker">BLOCO SELECTS / 01</div>
          <div className="display feature-title" role="heading" aria-level={2}>LIVE.<br />LOUD.<br /><span>LOCAL.</span></div>
          <p>A hand-picked edit of nights worth leaving the group chat for. Independent venues, new voices, and no filler.</p>
          <Button className="text-button" onClick={() => { setCategory('Music'); scrollToEvents() }}>Explore the edit <ArrowIcon /></Button>
        </div>
      </section>

      <section className="app-promo" id="about">
        <div className="float-card fc-one"><img src={photos.crowd} alt="" /></div>
        <div className="float-card fc-two"><img src={photos.portrait} alt="" /></div>
        <div className="float-card fc-three"><img src={photos.stage} alt="" /></div>
        <div className="float-card fc-four"><img src={photos.fashion} alt="" /></div>
        <div className="promo-copy">
          <div className="sound-mark">◖◗</div>
          <div className="display promo-title" role="heading" aria-level={2}>KEEP<br />IT LIVE.</div>
          <p>Stay updated and skip queues with the Bloco app.<br />Your city, in your pocket.</p>
          <div className="store-row">
            <Button className="store-button"><b>●</b><span>Download on the<strong>App Store</strong></span></Button>
            <Button className="store-button"><b>▶</b><span>GET IT ON<strong>Google Play</strong></span></Button>
          </div>
        </div>
      </section>

      <section className="organizer">
        <div className="organizer-cards">
          {[photos.party, photos.hero, photos.portrait, photos.performer, photos.fashion].map((photo, index) => (
            <div className={`organizer-card card-${index + 1}`} key={photo}><img src={photo} alt="" /></div>
          ))}
        </div>
        <div className="organizer-copy">
          <div className="kicker">FOR CREATORS</div>
          <div className="display organizer-title" role="heading" aria-level={2}>EARN MORE FROM<br />EVERY <span>YES.</span></div>
          <p>Sell tickets, grow faster, and join 40k+ independent organizers on Bloco.</p>
          <Button className="primary-button">Create an event <ArrowIcon /></Button>
        </div>
      </section>

      <footer>
        <div className="footer-brand">
          <Brand />
          <p>Stay updated and skip queues with the Bloco app.<br />Made for the moments you remember.</p>
        </div>
        <div className="footer-column"><strong>Explore</strong><span>All events</span><span>About us</span><span>My tickets</span></div>
        <div className="footer-column"><strong>Resources</strong><span>FAQs</span><span>Support</span><span>Privacy policy</span></div>
        <div className="footer-column"><strong>Get social</strong><span>Instagram</span><span>TikTok</span><span>Spotify</span></div>
        <div className="footer-bottom"><span>© BLOCO 2025</span><span>BRISTOL, UK</span><span>Terms & conditions</span></div>
      </footer>

      {selected && (
        <div className="modal-backdrop" onMouseDown={() => setSelected(null)}>
          <div className="event-modal" onMouseDown={(event) => event.stopPropagation()}>
            <Button className="modal-close" onClick={() => setSelected(null)} ariaLabel="Close event details"><CloseIcon /></Button>
            <div className="modal-image"><img src={selected.image} alt="" /></div>
            <div className="modal-copy">
              <div className="event-date">{selected.date}</div>
              <div className="display modal-title" role="heading" aria-level={2}>{selected.title}</div>
              <p>{selected.location}</p>
              <div className="modal-meta"><span>{selected.category}</span><span>{selected.price}</span></div>
              <Button className="primary-button">Get tickets <ArrowIcon /></Button>
            </div>
          </div>
        </div>
      )}
    </main>
  )
}
